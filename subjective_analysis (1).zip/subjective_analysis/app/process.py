import pandas as pd
import random
import csv
import pandas as pd
import tensorflow_hub as hub
import tensorflow_text
import tensorflow as tf
import numpy as np
import json
import re

# Load the Universal Sentence Encoder
use_model = hub.load("https://tfhub.dev/google/universal-sentence-encoder-multilingual/3")


def clean_text(text):
    # Remove non-alphanumeric characters and symbols
    cleaned_text = re.sub(r'[^\w\s]', '', text)
    return cleaned_text

def cosine_similarity(a, b):
    dot_product = np.dot(a, b)
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    return dot_product / (norm_a * norm_b)

def accuracy(expected_answer, answer):
    expected_answer = clean_text(expected_answer)
    answer = clean_text(answer)
    embedding1 = use_model([expected_answer])[0]
    embedding2 = use_model([answer])[0]
    match_avg = round(((cosine_similarity(embedding1, embedding2)) * 100) , 2)
    return match_avg

# Read the CSV file
df = pd.read_csv('dataset/dataset.csv')

def select_questions():
    # Select a random sample of 10 rows from the DataFrame
    sample_df = df.sample(n=10)

    # Get the questions from the 'Question' column of the sample DataFrame
    questions = sample_df['Question'].tolist()
    marks = sample_df['Marks'].tolist()
    return questions, marks

def check_answers(question_answer_dict):
    # Initialize an empty dictionary
    data_dict = {}
    marks_partial = []
    # Open the CSV file and read its contents
    with open('dataset/dataset.csv', 'r') as file:
        csv_reader = csv.DictReader(file)
        
        # Iterate over each row in the CSV file
        for row in csv_reader:
            question = row['Question']
            answer = row['Answer']
            
            # Store the question and its respective answer in the dictionary
            data_dict[question] = answer
    
    for question, answer in question_answer_dict.items():
        if question in data_dict:
            expected_answer = data_dict[question]
            match_avg = accuracy(expected_answer, answer)
            if match_avg > 50 :
                marks_partial.append(answer)
            else:
                marks_partial.append(0)
    
    return marks_partial